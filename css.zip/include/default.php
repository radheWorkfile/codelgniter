<?php 
 $company = 'ARYAMAN HIGHER EDUCATION';
 $company_1 = 'Aryaman Higher Education';
 $mobile_1 = '9308819517';
 $mobile_2 = '9430679729';
 $email = 'mrfoudation392@gmail.com';
 $address = "Arvind Marg, Lachchu Bihga, Nagarnausa, Nalanda - 801305";
 $facebook = 'www.facebook.com';
 $instagram = 'www.instagram.com';
 $teligram = 'www.teligram.com';
 $youtube = 'www.youtube.com';
 $twitter = 'www.twitter.com';

?>
<!-- <h1 class="card-title caption-line" id="typing-text"></h1> -->



